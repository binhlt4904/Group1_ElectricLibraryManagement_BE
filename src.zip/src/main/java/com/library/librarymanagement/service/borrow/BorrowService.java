package com.library.librarymanagement.service.borrow;

import com.library.librarymanagement.dto.request.BorrowRequest;
import com.library.librarymanagement.entity.Book;

public interface BorrowService {
    void borrowBook(BorrowRequest borrowRequest);
}
