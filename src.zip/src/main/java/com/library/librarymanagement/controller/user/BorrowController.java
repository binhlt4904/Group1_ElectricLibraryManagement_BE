package com.library.librarymanagement.controller.user;

import com.library.librarymanagement.dto.request.BorrowRequest;
import com.library.librarymanagement.dto.response.ApiResponse;
import com.library.librarymanagement.service.borrow.BorrowService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/borrow")
public class BorrowController {

    private final BorrowService borrowService;

    @PostMapping()
    @PreAuthorize("hasRole('READER')")
    public ResponseEntity<ApiResponse> borrow(@RequestBody BorrowRequest borrowRequest) {
        borrowService.borrowBook(borrowRequest);
        return ResponseEntity.ok(new ApiResponse(true, "Borrow Successful"));
    }
}
