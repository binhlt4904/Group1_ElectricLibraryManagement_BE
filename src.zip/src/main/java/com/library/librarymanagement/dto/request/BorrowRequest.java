package com.library.librarymanagement.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BorrowRequest {
    @NotBlank(message = "Card number is not blank")
    private String cardNumber;
    @NotBlank(message = "Book is not blank")
    private Long bookId;
}
