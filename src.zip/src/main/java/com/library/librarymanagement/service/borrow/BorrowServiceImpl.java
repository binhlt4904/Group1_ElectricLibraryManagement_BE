package com.library.librarymanagement.service.borrow;

import com.library.librarymanagement.dto.request.BorrowRequest;
import com.library.librarymanagement.repository.BorrowRepository;
import com.library.librarymanagement.service.custom_user_details.CustomUserDetails;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class BorrowServiceImpl implements BorrowService {

    private BorrowRepository borrowRepository;
    @Override
    public void borrowBook(BorrowRequest borrowRequest) {
        Long bookId = borrowRequest.getBookId();
        String cardNumber = borrowRequest.getCardNumber();

        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        Long accountId;
        if (principal instanceof CustomUserDetails userDetails) {
            accountId = userDetails.getAccountId();
        } else {
            throw new RuntimeException("Cannot extract accountId: invalid principal");
        }
        System.out.println("Account Id is " + accountId);
    }
}
