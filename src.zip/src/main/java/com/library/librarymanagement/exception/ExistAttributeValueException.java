package com.library.librarymanagement.exception;

public class ExistAttributeValueException extends RuntimeException {
    public ExistAttributeValueException(String message) {
        super(message);
    }
}
